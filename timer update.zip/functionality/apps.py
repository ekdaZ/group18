from django.apps import AppConfig


class FunctionalityConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "functionality"
